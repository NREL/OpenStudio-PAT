# frozen_string_literal: true

module ColorString
  VERSION = '0.0.2'
end
