module ColorString
  VERSION = '0.0.2'.freeze
end
