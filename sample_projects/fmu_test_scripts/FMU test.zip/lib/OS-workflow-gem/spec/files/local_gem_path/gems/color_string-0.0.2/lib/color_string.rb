# frozen_string_literal: true

require 'color_string/version'
require 'string'

module ColorString
  # Your code goes here...
end
