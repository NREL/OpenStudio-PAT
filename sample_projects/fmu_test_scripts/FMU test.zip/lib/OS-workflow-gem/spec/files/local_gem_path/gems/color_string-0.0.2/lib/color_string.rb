require 'color_string/version'
require 'string'

module ColorString
  # Your code goes here...
end
