

###### (Automatically generated documentation)

# Purposefully Broken Reporting Measure

## Description
A reporting measure that will fail in the reporting phase (after model successfully ran in E+) to test for #864

## Modeler Description
https://github.com/NREL/OpenStudio/issues/864

## Measure Type
ReportingMeasure

## Taxonomy


## Arguments




This measure does not have any user arguments


